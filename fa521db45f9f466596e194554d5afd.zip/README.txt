Features:
Game starts with one big Bubble, two small bubbles, A shooter which can shoot bullets and have health 3.
Shooter initially have health 3
If a big bubble hit the shooter, It's health reduces by 2.
If a small bubble hit the shooter, It's health reduces by 1.
Game ends if health of shooter becomes 0, or when time runs out.
Shooter can shoot bullets.
If bullet hits large bubble, that turns into two small bubbles and bullet disappears.
If bullet hits smaller bubble, both bubble and bubllet disappears.
Game ends if all the bubbles disappears.


Link for Video Recording - 
https://drive.google.com/file/d/1zC1jBDlJcS3Vfh4YHBY0wCiMfxRi4kAB/view?usp=sharing